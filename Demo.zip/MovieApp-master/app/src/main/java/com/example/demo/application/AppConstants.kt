package com.example.demo.application

object AppConstants {

    //API
    const val BASE_URL = "https://api.themoviedb.org/3/"
    const val API_KEY = "8cd13f584a4b55e728297b531679c8c8"
}